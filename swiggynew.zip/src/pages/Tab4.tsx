import React, { useState } from 'react';
import { IonList,IonInput,IonItemDivider,IonItem, IonCardTitle, IonCardSubtitle, IonIcon,IonContent, IonHeader, IonPage, IonTitle, IonToolbar, IonLabel, IonButton } from '@ionic/react';
import ExploreContainer from '../components/ExploreContainer';
import { arrowBack } from 'ionicons/icons';

import './Tab4.css';

const Tab2: React.FC = () => {
  const [text, setText] = useState<string>();
  const [number, setNumber] = useState<number>();

  return (
    <IonPage>
      <IonContent fullscreen>
        <IonHeader collapse="condense">
          <IonButton className="back-btn" color="light">
            <IonIcon className="arrow-back" icon={arrowBack}></IonIcon>
          </IonButton>
          </IonHeader>
          <IonContent>
            <img className="profile-img" src="assets/images/tab4.png" alt="image" />
            <IonCardTitle className="profile-title">LOGIN</IonCardTitle>
            <IonCardSubtitle className="profile-subtitle">Enter your phone number to continue</IonCardSubtitle>
            
            <IonItem className="phone-number">
              <IonLabel position="floating">PHONE NUMBER</IonLabel>
              <IonInput value={text}></IonInput>
            </IonItem>
            <IonButton color="swiggy" className="continue-btn"> CONTINUE </IonButton>
          </IonContent>
      </IonContent>
    </IonPage>
  );
};

export default Tab2;
