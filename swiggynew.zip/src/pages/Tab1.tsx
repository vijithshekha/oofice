import React from 'react';
import { IonItemDivider,IonInfiniteScroll,IonItem,IonList, IonCardTitle,IonCardSubtitle,IonCardHeader,IonCardContent,IonButton, IonCard, IonContent, IonHeader, IonIcon, IonLabel, IonPage, IonSlides, IonTitle, IonToolbar, IonVirtualScroll, IonAvatar } from '@ionic/react';


import ExploreContainer from '../components/ExploreContainer';
import './Tab1.css';
import src from '*.bmp';
import {bicycle, chevronDownOutline, logoFacebook, pricetag, starOutline,} from 'ionicons/icons';

const Tab1: React.FC = () => {
  return (
  <IonPage>
      <IonHeader>
        <IonLabel>
        <IonCard className="Page-top"> 
            <IonCardHeader>
            <IonCardTitle className="location-title"> Yeyyadi <IonIcon className="dropDown_loc" icon={chevronDownOutline} /></IonCardTitle>
            <IonCardSubtitle className="location-subtitle">Unamed road, Yeyyadi, Mangalore...</IonCardSubtitle>
            <IonButton color="transparent" className="offers-btn" href="./Tab4"><img className="offer-img" src="assets/images/offer-icon.png" alt="image"/><IonLabel color="blacknwhite" className="Offers-text"> Offers </IonLabel></IonButton>
            </IonCardHeader>
        </IonCard>
        </IonLabel>
      </IonHeader>

    <IonContent fullscreen>
        <IonSlides>
          <IonCard className="cards"> <img src="assets/images/card1.jpeg" alt="image" /></IonCard>
          <IonCard className="cards"> <img src="assets/images/card2.jpeg" alt="image" /></IonCard>
          <IonCard className="cards"> <img src="assets/images/card2.jpeg" alt="image" /></IonCard>
          <IonCard className="cards"> <img src="assets/images/card2.jpeg" alt="image" /></IonCard>
          <IonCard className="cards"> <img src="assets/images/card2.jpeg" alt="image" /></IonCard>
          <IonCard className="cards"> <img src="assets/images/card2.jpeg" alt="image" /></IonCard>
        </IonSlides>

      <IonSlides className="slider-one">
          <IonCard className="MainCard"> 
            <IonCardHeader>
                <img className="MainImg" src="assets/images/safety.png" alt="image" />
                <IonCardSubtitle className="title_Styles">Best In Safety</IonCardSubtitle>
            </IonCardHeader>
        </IonCard>
        <IonCard className="MainCard"> 
            <IonCardHeader>
                <img className="MainImg" src="assets/images/delivery.png" alt="image" />
                <IonCardSubtitle className="title_Styles">Free Delivery</IonCardSubtitle>
            </IonCardHeader>
        </IonCard>
        <IonCard className="MainCard"> 
            <IonCardHeader>
                <img className="MainImg" src="assets/images/newly launched.png" alt="image" />
                <IonCardSubtitle className="title_Styles">Veg Only</IonCardSubtitle>
            </IonCardHeader>
        </IonCard>
        <IonCard className="MainCard"> 
            <IonCardHeader>
                <img className="MainImg" src="assets/images/newly launched.png" alt="image" />
                <IonCardSubtitle className="title_Styles">New</IonCardSubtitle>
            </IonCardHeader>
        </IonCard>
        <IonCard className="MainCard"> 
            <IonCardHeader>
                <img className="MainImg" src="assets/images/express.png" alt="image" />
                <IonCardSubtitle className="title_Styles">Express Delivery</IonCardSubtitle>
            </IonCardHeader>
        </IonCard>
        <IonCard className="MainCard"> 
            <IonCardHeader>
                <img className="MainImg" src="assets/images/delivery.png" alt="image" />
                <IonCardSubtitle className="title_Styles">Top Rated</IonCardSubtitle>
            </IonCardHeader>
        </IonCard>
      </IonSlides>

      
        <IonCard className="retuarant-heading">
          <IonLabel className="restaurant">ALL RESTAURANT</IonLabel>
          <IonLabel className="filterText">Sort / Filter</IonLabel>
          <img className="filterimg" src="assets/images/filter.png" alt="image" />
        </IonCard>
          <IonList className="restuarant-list">
              <IonCard>
                <img className="restaurant-img" src="assets/images/card1.jpeg" alt="image" />
                <IonCardTitle className="restaurant-title">Juice Junction</IonCardTitle>
                <IonCardSubtitle className="restaurant-subtitle">Snacks, Beverages </IonCardSubtitle> 
                <IonCardContent className="card-contents"> <IonIcon className="restuarant-offericon" icon={pricetag}></IonIcon> 5% off on orders above $149</IonCardContent>
                <IonCardContent className="ratings"><IonIcon className="rating-icon" icon={starOutline}/>4.4 . 44MINS . $150 FOR TWO</IonCardContent>
              </IonCard>
              <IonCard>
                <img className="restaurant-img" src="assets/images/card2.jpeg" alt="image" />
                <IonCardTitle className="restaurant-title">Juice Junction</IonCardTitle>
                <IonCardSubtitle className="restaurant-subtitle">Snacks, Beverages </IonCardSubtitle> 
                <IonCardContent className="card-contents"> <IonIcon className="restuarant-offericon" icon={pricetag}></IonIcon> 5% off on orders above $149</IonCardContent>
                <IonCardContent className="ratings"><IonIcon className="rating-icon" icon={starOutline}/>4.4 . 44MINS . $150 FOR TWO</IonCardContent>
              </IonCard>
              <IonCard>
                <img className="restaurant-img" src="assets/images/card1.jpeg" alt="image" />
                <IonCardTitle className="restaurant-title">Juice Junction</IonCardTitle>
                <IonCardSubtitle className="restaurant-subtitle">Snacks, Beverages </IonCardSubtitle> 
                <IonCardContent className="card-contents"> <IonIcon className="restuarant-offericon" icon={pricetag}></IonIcon> 5% off on orders above $149</IonCardContent>
                <IonCardContent className="ratings"><IonIcon className="rating-icon" icon={starOutline}/>4.4 . 44MINS . $150 FOR TWO</IonCardContent>
              </IonCard>
              <IonCard>
                <img className="restaurant-img" src="assets/images/card2.jpeg" alt="image" />
                <IonCardTitle className="restaurant-title">Juice Junction</IonCardTitle>
                <IonCardSubtitle className="restaurant-subtitle">Snacks, Beverages </IonCardSubtitle> 
                <IonCardContent className="card-contents"> <IonIcon className="restuarant-offericon" icon={pricetag}></IonIcon> 5% off on orders above $149</IonCardContent>
                <IonCardContent className="ratings"><IonIcon className="rating-icon" icon={starOutline}/>4.4 . 44MINS . $150 FOR TWO</IonCardContent>
              </IonCard>
              
          </IonList>

              <IonLabel className="Brands">Popular Brands</IonLabel> <br/>
              
              <IonSlides className="brands-slider">
              <IonButton color="light" className="brands-btn" ><img className="restaurant-img" src="assets/images/Mc.png" alt="image" /></IonButton>
                <IonButton color="light" className="brands-btn" ><img className="restaurant-img" src="assets/images/kfc.png" alt="image" /></IonButton>
                <IonButton color="light" className="brands-btn" ><img className="restaurant-img" src="assets/images/pizza.png" alt="image" /></IonButton>
                <IonButton color="light" className="brands-btn" ><img className="restaurant-img" src="assets/images/cafe.png" alt="image" /></IonButton>
                <IonButton color="light" className="brands-btn" ><img className="restaurant-img" src="assets/images/Mc.png" alt="image" /></IonButton>
                <IonButton color="light" className="brands-btn" ><img className="restaurant-img" src="assets/images/kfc.png" alt="image" /></IonButton>
                <IonButton color="light" className="brands-btn" ><img className="restaurant-img" src="assets/images/pizza.png" alt="image" /></IonButton>
                <IonButton color="light" className="brands-btn" ><img className="restaurant-img" src="assets/images/cafe.png" alt="image" /></IonButton>
              </IonSlides>

              <IonList>
              <IonCard>
                  <img className="restaurant-img" src="assets/images/card1.jpeg" alt="image" />
                  <IonCardTitle className="restaurant-title">Juice Junction</IonCardTitle>
                  <IonCardSubtitle className="restaurant-subtitle">Snacks, Beverages </IonCardSubtitle> 
                  <IonCardContent className="card-contents"> <IonIcon className="restuarant-offericon" icon={pricetag}></IonIcon> 5% off on orders above $149</IonCardContent>
                  <IonCardContent className="ratings"><IonIcon className="rating-icon" icon={starOutline}/>4.4 . 44MINS . $150 FOR TWO</IonCardContent>
                </IonCard>
                <IonCard>
                  <img className="restaurant-img" src="assets/images/card2.jpeg" alt="image" />
                  <IonCardTitle className="restaurant-title">Juice Junction</IonCardTitle>
                  <IonCardSubtitle className="restaurant-subtitle">Snacks, Beverages </IonCardSubtitle> 
                  <IonCardContent className="card-contents"> <IonIcon className="restuarant-offericon" icon={pricetag}></IonIcon> 5% off on orders above $149</IonCardContent>
                  <IonCardContent className="ratings"><IonIcon className="rating-icon" icon={starOutline}/>4.4 . 44MINS . $150 FOR TWO</IonCardContent>
                </IonCard>
                <IonCard>
                  <img className="restaurant-img" src="assets/images/card1.jpeg" alt="image" />
                  <IonCardTitle className="restaurant-title">Juice Junction</IonCardTitle>
                  <IonCardSubtitle className="restaurant-subtitle">Snacks, Beverages </IonCardSubtitle> 
                  <IonCardContent className="card-contents"> <IonIcon className="restuarant-offericon" icon={pricetag}></IonIcon> 5% off on orders above $149</IonCardContent>
                  <IonCardContent className="ratings"><IonIcon className="rating-icon" icon={starOutline}/>4.4 . 44MINS . $150 FOR TWO</IonCardContent>
                </IonCard>
                <IonCard>
                  <img className="restaurant-img" src="assets/images/card2.jpeg" alt="image" />
                  <IonCardTitle className="restaurant-title">Juice Junction</IonCardTitle>
                  <IonCardSubtitle className="restaurant-subtitle">Snacks, Beverages </IonCardSubtitle> 
                  <IonCardContent className="card-contents"> <IonIcon className="restuarant-offericon" icon={pricetag}></IonIcon> 5% off on orders above $149</IonCardContent>
                  <IonCardContent className="ratings"><IonIcon className="rating-icon" icon={starOutline}/>4.4 . 44MINS . $150 FOR TWO</IonCardContent>
                </IonCard>
                <IonCard>
                <img className="restaurant-img" src="assets/images/card1.jpeg" alt="image" />
                <IonCardTitle className="restaurant-title">Juice Junction</IonCardTitle>
                <IonCardSubtitle className="restaurant-subtitle">Snacks, Beverages </IonCardSubtitle> 
                <IonCardContent className="card-contents"> <IonIcon className="restuarant-offericon" icon={pricetag}></IonIcon> 5% off on orders above $149</IonCardContent>
                <IonCardContent className="ratings"><IonIcon className="rating-icon" icon={starOutline}/>4.4 . 44MINS . $150 FOR TWO</IonCardContent>
              </IonCard>
              <IonCard>
                <img className="restaurant-img" src="assets/images/card2.jpeg" alt="image" />
                <IonCardTitle className="restaurant-title">Juice Junction</IonCardTitle>
                <IonCardSubtitle className="restaurant-subtitle">Snacks, Beverages </IonCardSubtitle> 
                <IonCardContent className="card-contents"> <IonIcon className="restuarant-offericon" icon={pricetag}></IonIcon> 5% off on orders above $149</IonCardContent>
                <IonCardContent className="ratings"><IonIcon className="rating-icon" icon={starOutline}/>4.4 . 44MINS . $150 FOR TWO</IonCardContent>
              </IonCard>
              <IonCard>
                <img className="restaurant-img" src="assets/images/card1.jpeg" alt="image" />
                <IonCardTitle className="restaurant-title">Juice Junction</IonCardTitle>
                <IonCardSubtitle className="restaurant-subtitle">Snacks, Beverages </IonCardSubtitle> 
                <IonCardContent className="card-contents"> <IonIcon className="restuarant-offericon" icon={pricetag}></IonIcon> 5% off on orders above $149</IonCardContent>
                <IonCardContent className="ratings"><IonIcon className="rating-icon" icon={starOutline}/>4.4 . 44MINS . $150 FOR TWO</IonCardContent>
              </IonCard>
              <IonCard>
                <img className="restaurant-img" src="assets/images/card2.jpeg" alt="image" />
                <IonCardTitle className="restaurant-title">Juice Junction</IonCardTitle>
                <IonCardSubtitle className="restaurant-subtitle">Snacks, Beverages </IonCardSubtitle> 
                <IonCardContent className="card-contents"> <IonIcon className="restuarant-offericon" icon={pricetag}></IonIcon> 5% off on orders above $149</IonCardContent>
                <IonCardContent className="ratings"><IonIcon className="rating-icon" icon={starOutline}/>4.4 . 44MINS . $150 FOR TWO</IonCardContent>
              </IonCard>
              </IonList>
              
    </IonContent>
  </IonPage>
  );
};

export default Tab1;
