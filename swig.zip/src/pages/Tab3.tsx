import React from 'react';
import { IonCard, IonCardSubtitle, IonCardTitle, IonContent, IonHeader, IonPage, IonTitle, IonToolbar } from '@ionic/react';
import ExploreContainer from '../components/ExploreContainer';
import './Tab3.css';

const Tab3: React.FC = () => {
  return (
    <IonPage>
      <IonContent fullscreen>
        <IonHeader collapse="condense">
          <img className="Cart-img" src="assets/images/cart.png" alt="image" />
          <IonCardTitle className="cart-title">Good food is always cooking</IonCardTitle>
          <IonCardSubtitle className="cart-subtitle">Your cart is empty. Add something from the menu</IonCardSubtitle>
        </IonHeader>
      </IonContent>
    </IonPage>
  );
};

export default Tab3;
