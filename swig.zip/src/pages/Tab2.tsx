import React, { useState } from 'react';
import { IonFooter,IonSearchbar,IonContent, IonHeader, IonPage, IonTitle, IonToolbar, IonSlides, IonSlide, IonButton, IonIcon } from '@ionic/react';
import ExploreContainer from '../components/ExploreContainer';
import './Tab2.css';

const Tab2: React.FC = () => {
  const [searchText, setSearchText] = useState('');
  return (
    <IonPage>
      <IonHeader>
      </IonHeader>
      {/* <IonContent>
        <IonSearchbar value={searchText} onIonChange={e => setSearchText(e.detail.value!)}></IonSearchbar>
      </IonContent> */}
       <IonContent fullscreen class="ion-padding" scroll-y="false">
      <IonSlides>

        <IonSlide>
            <img src="assets/images/card1.jpeg"/>
        </IonSlide>

        <IonSlide>
            <img src="assets/images/card1.jpeg"/>
        </IonSlide>
        <IonSlide>
            <img src="assets/images/card1.jpeg"/>
        </IonSlide>
      

        <IonSlide>
          <img src="./slide-2.png"/>
          <h2>What is Ionic?</h2>
          <p><b>Ionic Framework</b> is an open source SDK that enables developers to build high quality mobile apps with web technologies like HTML, CSS, and JavaScript.</p>
        </IonSlide>

        <IonSlide>
          <img src="./slide-3.png"/>
          <h2>What is Ionic Appflow?</h2>
          <p><b>Ionic Appflow</b> is a powerful set of services and features built on top of Ionic Framework that brings a totally new level of app development agility to mobile dev teams.</p>
        </IonSlide>

        <IonSlide>
          <img src="./slide-4.png"/>
          <h2>Ready to Play?</h2>
          <IonButton fill="clear">Continue <IonIcon slot="end" name="arrow-forward"></IonIcon></IonButton>
        </IonSlide>
      </IonSlides>
    </IonContent>

    </IonPage>
  );
};

export default Tab2;
