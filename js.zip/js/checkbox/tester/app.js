const btn = document.querySelector('#btn');

    let selectedValue;
    btn.onclick = function Check() {
        const rbs = document.querySelectorAll('input[name="choice"]');
        for (const rb of rbs) {
            if (rb.checked) {
                selectedValue = rb.value;
                break;
            }
        }
        alert(selectedValue);
    


    const statusDisplay = document.querySelector('.game--status');
    let gameActive = true;
    let currentPlayer = selectedValue;
    let gameState = ["", "", "", "", "", "", "", "", ""];

    const winningMessage = () => `Player ${currentPlayer} has won!`;

    const drawMessage = () => `Game ended in a draw!`;

    const currentPlayerTurn = () => `It's ${currentPlayer}'s turn`;

    statusDisplay.innerHTML = currentPlayerTurn();
    
    function handleCellPlayed() {

    }
    function handlePlayerChange() {

    }
    function handleResultValidation() {

    }
    function handleCellClick() {

    }
    document.querySelectorAll('.cell').forEach(cell => cell.addEventListener('click', handleCellClick));


    //2
    function handleCellClick(clickedCellEvent) {   
        const clickedCell = clickedCellEvent.target;
        const clickedCellIndex = parseInt(
        clickedCell.getAttribute('data-cell-index')
        );
        if (gameState[clickedCellIndex] !== "" || !gameActive) {
            return;
        }  
        handleCellPlayed(clickedCell, clickedCellIndex);
        handleResultValidation();
    }

//     //3

    function handleCellPlayed(clickedCell, clickedCellIndex) {
        gameState[clickedCellIndex] = currentPlayer;
        clickedCell.innerHTML = currentPlayer;
    }

};